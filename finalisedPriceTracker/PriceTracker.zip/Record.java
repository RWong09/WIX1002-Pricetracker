package PriceTracker;

public class Record {
    private String premise;
    private double price;
    private String address;

    public Record(String premise, double price, String address) {
        this.premise = premise;
        this.price = price;
        this.address = address;
    }

    // Getter and Setter methods
    public String getPremise() {
        return premise;
    }
    public double getPrice() {
        return price;
    }

    public String getAddress() {
        return address;
    }
}
